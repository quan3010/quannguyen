+++
# People widget.
widget = "people"  # See https://sourcethemes.com/academic/docs/page-builder/
headless = true  # This file represents a page section.
active = false  # Activate this widget? true/false
weight = 68  # Order that this section will appear.

title = "People"
subtitle = ""

# List user groups to display.
#   Edit each user's `user_groups` to add them to one or more of these groups.
user_groups = ["Principal Investigators",
               "Researchers",
               "Grad Students",
               "Administration",
               "Visitors",
               "Alumni"]
+++
